export const NativeText = require('react-native/Libraries/Text/TextNativeComponent');

// export const AnimatedNativeText = Animated.createAnimatedComponent(NativeText);
