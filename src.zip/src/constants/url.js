export const URL_TYPE = 'https://';

export const API_URL = 'api/v1/';

export const HELP_URL = 'https://www.chatwoot.com/help-center';

export const GRAVATAR_URL = 'https://www.gravatar.com/avatar/';
