export default {
  conversations: [
    {
      id: 1,
      account_id: 1,
      inbox_id: 1,
      status: 'open',
      messages: [
        {
          id: 2,
          content: 'hey how may i help you?',
          message_type: 0,
        },
        {
          id: 3,
          content: 'Give the team a way to reach you',
          message_type: 0,
        },
      ],
      updated_at: '2022-10-31T10:22:29.660Z',
    },
  ],
  meta: {
    mine_count: 1,
    unassigned_count: 0,
    all_count: 1,
  },
};
