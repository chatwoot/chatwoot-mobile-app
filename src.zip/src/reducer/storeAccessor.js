let store;

export const setStore = appStore => {
  store = appStore;
};

export const getStore = () => store;
