import React, { useMemo, useEffect, useCallback, useState, useRef } from 'react';
import { useTheme } from '@react-navigation/native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useSelector, useDispatch } from 'react-redux';
import { View, ScrollView, AppState, Dimensions } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import * as Sentry from '@sentry/react-native';

import { getInboxIconByType } from 'helpers/inboxHelpers';
import { clearAllDeliveredNotifications } from 'helpers/PushHelper';
import {
  selectConversationStatus,
  selectAssigneeType,
  selectActiveInbox,
  setAssigneeType,
  setConversationStatus,
  clearAllConversations,
  setActiveInbox,
  setSortFilter,
  selectConversationMeta,
  selectSortFilter,
} from 'reducer/conversationSlice';
import { clearContacts } from 'reducer/contactSlice';
import conversationActions from 'reducer/conversationSlice.action';
import createStyles from './ConversationScreen.style';
import i18n from 'i18n';
import { FilterButton, ClearFilterButton, Header } from 'components';
import BottomSheetModal from 'components/BottomSheet/BottomSheet';
import { ConversationList, ConversationFilter, ConversationInboxFilter } from './components';
import { CONVERSATION_STATUSES, ASSIGNEE_TYPES, SORT_TYPES } from 'constants';
import AnalyticsHelper from 'helpers/AnalyticsHelper';
import { CONVERSATION_EVENTS } from 'constants/analyticsEvents';
import { actions as inboxActions, inboxesSelector } from 'reducer/inboxSlice';
import { selectUser } from '@/store/auth/authSelectors';
import { getUserPermissions } from 'helpers/permissionHelper';
import { CONVERSATION_PERMISSIONS } from 'constants/permissions';
import { useAppDispatch, useAppSelector } from '@/hooks';
import { selectInstallationUrl } from '@/store/settings/settingsSelectors';
import { settingsActions } from '@/store/settings/settingsActions';
import { actions as dashboardAppActions } from 'reducer/dashboardAppSlice';
import { getCurrentRouteName } from 'helpers/NavigationHelper';
import { actions as labelActions } from 'reducer/labelSlice';
import { actions as teamActions } from 'reducer/teamSlice';
import { SCREENS } from 'constants';
const deviceHeight = Dimensions.get('window').height;

// The screen list thats need to be checked for refresh notification list
const REFRESH_SCREEN_LIST = [SCREENS.CONVERSATION, SCREENS.NOTIFICATION, SCREENS.SETTINGS];

const ConversationScreen = () => {
  const [appState, setAppState] = useState(AppState.currentState);
  const theme = useTheme();
  const { colors } = theme;
  const styles = useMemo(() => createStyles(theme), [theme]);
  const conversationStatus = useSelector(selectConversationStatus);
  const assigneeType = useSelector(selectAssigneeType);
  const sortFilter = useSelector(selectSortFilter) || SORT_TYPES[0].key;
  const activeInboxId = useSelector(selectActiveInbox);
  const installationUrl = useAppSelector(selectInstallationUrl);
  const isLoading = useSelector(state => state.conversations.loading);
  const inboxes = useSelector(inboxesSelector.selectAll);
  const user = useAppSelector(selectUser);
  const userPermissions = getUserPermissions(user, user.account_id);
  // If userPermissions contains any values conversation_manage_permission,administrator, agent then keep all the assignee types
  // If conversation_manage is not available and conversation_unassigned_manage only is available, then return only unassigned and mine
  // If conversation_manage is not available and conversation_participating_manage only is available, then return only all and mine
  let assigneeTypes = ASSIGNEE_TYPES;

  if (
    userPermissions.includes('conversation_manage') ||
    userPermissions.includes('agent') ||
    userPermissions.includes('administrator')
  ) {
    assigneeTypes = ASSIGNEE_TYPES;
  } else if (userPermissions.includes('conversation_unassigned_manage')) {
    assigneeTypes = ASSIGNEE_TYPES.filter(type => type.key !== 'all');
  } else {
    assigneeTypes = ASSIGNEE_TYPES.filter(type => type.key !== 'unassigned');
  }
  const [pageNumber, setPage] = useState(1);
  const dispatch = useDispatch();
  const appDispatch = useAppDispatch();

  useEffect(() => {
    dispatch(clearContacts());
    dispatch(clearAllConversations());
    dispatch(inboxActions.fetchInboxes());
    initAnalytics();
    initSentry();
    initPushNotifications();
    dispatch(dashboardAppActions.index());
    dispatch(labelActions.index());
    dispatch(teamActions.index());
  }, [dispatch, initAnalytics, initPushNotifications, initSentry]);

  const initPushNotifications = useCallback(async () => {
    clearAllDeliveredNotifications();
  }, [dispatch]);

  const initAnalytics = useCallback(async () => {
    AnalyticsHelper.identify(user);
  }, [user]);

  const initSentry = useCallback(async () => {
    Sentry.setUser({
      id: user.id,
      email: user.email,
      account_id: user.account_id,
      name: user.name,
      role: user.role,
      installation_url: installationUrl,
    });
  }, [user, installationUrl]);

  // Update notifications when app comes to foreground from background
  useEffect(() => {
    const appStateListener = AppState.addEventListener('change', nextAppState => {
      if (appState.match(/inactive|background/) && nextAppState === 'active') {
        const routeName = getCurrentRouteName();
        if (REFRESH_SCREEN_LIST.includes(routeName)) {
          refreshConversationsAgain();
        }
      }
      setAppState(nextAppState);
    });
    return () => {
      appStateListener?.remove();
    };
  }, [appState, refreshConversationsAgain]);

  const onChangePage = async () => {
    setPage(pageNumber + 1);
  };

  const refreshConversationsAgain = useCallback(async () => {
    await dispatch(clearContacts());
    await dispatch(clearAllConversations());
    setPage(1);
    loadConversations({
      page: 1,
      assignee: assigneeType,
      status: conversationStatus,
      inboxId: activeInboxId,
      sortBy: sortFilter,
    });
  }, [dispatch, assigneeType, conversationStatus, activeInboxId, loadConversations, sortFilter]);

  const refreshConversations = async () => {
    AnalyticsHelper.track(CONVERSATION_EVENTS.REFRESH_CONVERSATIONS);
    await dispatch(clearContacts());
    await dispatch(clearAllConversations());
    setPage(1);
    loadConversations({
      page: 1,
      assignee: assigneeType,
      status: conversationStatus,
      inboxId: activeInboxId,
      sortBy: sortFilter,
    });
  };

  useEffect(() => {
    loadConversations({
      page: pageNumber,
      assignee: assigneeType,
      status: conversationStatus,
      inboxId: activeInboxId,
      sortBy: sortFilter,
    });
  }, [pageNumber, assigneeType, conversationStatus, activeInboxId, loadConversations, sortFilter]);

  const loadConversations = useCallback(
    ({ page, assignee, status, inboxId, sortBy }) => {
      dispatch(
        conversationActions.fetchConversations({
          pageNumber: page,
          assigneeType: assignee,
          conversationStatus: status,
          inboxId: inboxId,
          sortBy,
        }),
      );
    },
    [dispatch],
  );

  const clearAppliedFilters = async () => {
    AnalyticsHelper.track(CONVERSATION_EVENTS.CLEAR_FILTERS);
    await dispatch(clearContacts());
    await dispatch(clearAllConversations());
    await dispatch(setConversationStatus('open'));
    await dispatch(setAssigneeType('mine'));
    await dispatch(setActiveInbox(0));
    await dispatch(setSortFilter('latest'));
    setPage(1);
  };

  const conversationMetaDetails = useSelector(selectConversationMeta);

  const conversationCount = () => {
    switch (assigneeType) {
      case 'mine':
        return conversationMetaDetails.mine_count;
      case 'unassigned':
        return conversationMetaDetails.unassigned_count;
      case 'all':
        return conversationMetaDetails.all_count;
      default:
        return 0;
    }
  };

  const onSelectAssigneeType = async item => {
    AnalyticsHelper.track(CONVERSATION_EVENTS.APPLY_FILTER, {
      type: 'assignee-type',
      value: item.key,
    });
    await dispatch(setAssigneeType(item.key));
    setPage(1);
    closeConversationAssigneeModal();
  };

  const onSelectConversationStatus = async item => {
    AnalyticsHelper.track(CONVERSATION_EVENTS.APPLY_FILTER, {
      type: 'status',
      value: item.key,
    });
    await dispatch(clearContacts());
    await dispatch(clearAllConversations());
    await dispatch(setConversationStatus(item.key));
    setPage(1);
    closeConversationStatusModal();
  };

  const onChangeInbox = async item => {
    AnalyticsHelper.track(CONVERSATION_EVENTS.APPLY_FILTER, {
      type: 'inbox',
    });
    await dispatch(clearContacts());
    await dispatch(clearAllConversations());
    await dispatch(setActiveInbox(item.id));
    setPage(1);
    closeInboxFilterModal();
  };

  const onSelectSortFilter = async item => {
    AnalyticsHelper.track(CONVERSATION_EVENTS.APPLY_FILTER, {
      type: 'sort',
    });
    await dispatch(clearContacts());
    await dispatch(clearAllConversations());
    await dispatch(setSortFilter(item.key));
    setPage(1);
    closeSortFilterModal();
  };

  useFocusEffect(
    useCallback(() => {
      return () => {
        closeInboxFilterModal();
        closeConversationStatusModal();
        closeConversationAssigneeModal();
      };
    }, [closeConversationAssigneeModal, closeConversationStatusModal, closeInboxFilterModal]),
  );

  // Conversation filter modal
  const conversationFilterModalSnapPoints = useMemo(
    () => [deviceHeight - 400, deviceHeight - 400],
    [],
  );

  // Filter by assignee type
  const conversationAssigneeModal = useRef(null);
  const toggleConversationAssigneeModal = useCallback(() => {
    conversationAssigneeModal.current.present() || conversationAssigneeModal.current?.dismiss();
  }, []);
  const closeConversationAssigneeModal = useCallback(() => {
    conversationAssigneeModal.current?.dismiss();
  }, []);

  // Filter by conversation status
  const conversationStatusModal = useRef(null);
  const toggleConversationStatusModal = useCallback(() => {
    conversationStatusModal.current.present() || conversationStatusModal.current?.dismiss();
  }, []);
  const closeConversationStatusModal = useCallback(() => {
    conversationStatusModal.current?.dismiss();
  }, []);

  // Inbox filter modal
  const inboxFilterModal = useRef(null);
  const inboxFilterModalSnapPoints = useMemo(() => [deviceHeight - 210, deviceHeight - 210], []);
  const toggleInboxFilterModal = useCallback(() => {
    inboxFilterModal.current.present() || inboxFilterModal.current?.dismiss();
  }, []);
  const closeInboxFilterModal = useCallback(() => {
    inboxFilterModal.current?.dismiss();
  }, []);

  // Sort filter modal
  const sortFilterModal = useRef(null);
  const toggleSortFilterModal = useCallback(() => {
    sortFilterModal.current.present() || sortFilterModal.current?.dismiss();
  }, []);
  const closeSortFilterModal = useCallback(() => {
    sortFilterModal.current?.dismiss();
  }, []);

  const hasActiveFilters =
    conversationStatus !== 'open' ||
    assigneeType !== 'mine' ||
    activeInboxId !== 0 ||
    sortFilter !== 'latest';

  const filtersCount =
    Number(conversationStatus !== 'open') +
    Number(assigneeType !== 'mine') +
    Number(activeInboxId !== 0) +
    Number(sortFilter !== 'latest');

  const activeInboxDetails = inboxes.find(inbox => inbox.id === activeInboxId);
  const iconNameByInboxType = () => {
    if (!activeInboxId) {
      return 'chat-outline';
    }
    const channelType = activeInboxDetails?.channel_type;
    const phoneNumber = activeInboxDetails?.phone_number;
    if (!channelType) {
      return '';
    }
    return getInboxIconByType({ channelType, phoneNumber });
  };

  const inboxName =
    activeInboxDetails?.name === 'All'
      ? i18n.t('FILTER.ALL_INBOXES')
      : activeInboxDetails?.name || i18n.t('FILTER.ALL_INBOXES');

  const headerText = isLoading
    ? i18n.t('CONVERSATION.UPDATING')
    : i18n.t('CONVERSATION.DEFAULT_HEADER_TITLE');

  return (
    <SafeAreaView edges={['top', 'left', 'right']} style={styles.container}>
      <Header headerText={headerText} loading={isLoading} showCount count={conversationCount()} />
      <View style={styles.filterContainer}>
        <ScrollView
          horizontal
          contentContainerStyle={styles.filterScrollView}
          showsHorizontalScrollIndicator={false}>
          {hasActiveFilters && (
            <ClearFilterButton count={filtersCount} onSelectItem={clearAppliedFilters} />
          )}
          <FilterButton
            label={assigneeTypes.map(item => (item.key === assigneeType ? item.name : null))}
            hasLeftIcon={false}
            onPress={toggleConversationAssigneeModal}
            isActive={assigneeType !== 'mine'}
          />
          <FilterButton
            label={CONVERSATION_STATUSES.map(item =>
              item.key === conversationStatus ? item.name : null,
            )}
            hasLeftIcon={false}
            onPress={toggleConversationStatusModal}
            isActive={conversationStatus !== 'open'}
          />
          <FilterButton
            label={inboxName}
            hasLeftIcon={true}
            leftIconName={iconNameByInboxType()}
            onPress={toggleInboxFilterModal}
            isActive={activeInboxId !== 0}
          />
          <FilterButton
            label={`Sort: ${
              SORT_TYPES.find(item => (item.key === sortFilter ? item.name : null)).name
            }`}
            onPress={toggleSortFilterModal}
            isActive={sortFilter !== 'latest'}
          />
        </ScrollView>
        <BottomSheetModal
          bottomSheetModalRef={conversationAssigneeModal}
          initialSnapPoints={conversationFilterModalSnapPoints}
          showHeader
          headerTitle={i18n.t('FILTER.FILTER_BY_ASSIGNEE_TYPE')}
          closeFilter={closeConversationAssigneeModal}
          children={
            <ConversationFilter
              activeValue={assigneeType}
              items={assigneeTypes}
              onChangeFilter={onSelectAssigneeType}
              colors={colors}
            />
          }
        />
        <BottomSheetModal
          bottomSheetModalRef={sortFilterModal}
          initialSnapPoints={conversationFilterModalSnapPoints}
          showHeader
          headerTitle={i18n.t('FILTER.SORT_BY')}
          closeFilter={closeSortFilterModal}
          children={
            <ConversationFilter
              activeValue={sortFilter}
              items={SORT_TYPES}
              onChangeFilter={onSelectSortFilter}
              colors={colors}
            />
          }
        />
        <BottomSheetModal
          bottomSheetModalRef={conversationStatusModal}
          initialSnapPoints={conversationFilterModalSnapPoints}
          showHeader
          headerTitle={i18n.t('FILTER.FILTER_BY_CONVERSATION_STATUS')}
          closeFilter={closeConversationStatusModal}
          children={
            <ConversationFilter
              activeValue={conversationStatus}
              items={CONVERSATION_STATUSES}
              onChangeFilter={onSelectConversationStatus}
              colors={colors}
            />
          }
        />
        <BottomSheetModal
          bottomSheetModalRef={inboxFilterModal}
          initialSnapPoints={inboxFilterModalSnapPoints}
          showHeader
          headerTitle={i18n.t('FILTER.FILTER_BY_INBOX')}
          closeFilter={closeInboxFilterModal}
          children={
            <ConversationInboxFilter
              activeValue={activeInboxId}
              hasLeftIcon={true}
              items={inboxes}
              onChangeFilter={onChangeInbox}
              colors={colors}
            />
          }
        />
      </View>
      <View style={styles.container}>
        <ConversationList
          onChangePageNumber={onChangePage}
          refreshConversations={refreshConversations}
          assigneeType={assigneeType}
          conversationStatus={conversationStatus}
          activeInboxId={activeInboxId}
          sortBy={sortFilter}
          isCountEnabled
        />
      </View>
    </SafeAreaView>
  );
};

export default ConversationScreen;
