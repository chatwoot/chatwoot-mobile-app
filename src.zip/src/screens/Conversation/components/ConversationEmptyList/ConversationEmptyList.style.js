import { StyleSheet } from 'react-native';

export default theme => {
  return StyleSheet.create({
    container: {
      minHeight: 64,
    },
  });
};
