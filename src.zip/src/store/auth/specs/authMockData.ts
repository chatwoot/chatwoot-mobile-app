export const mockUser = {
  id: 1,
  email: 'test@example.com',
  name: 'Test User',
  account_id: 123,
};

export const mockHeaders = {
  'access-token': 'SxsseweDSEWESDSSSSFDFDf',
  uid: 'uid',
  client: 'client',
};
