import { create } from 'twrnc';

import { twConfig } from './tailwind.config';

export const tailwind = create(twConfig);
