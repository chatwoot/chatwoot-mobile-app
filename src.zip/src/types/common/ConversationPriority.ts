export type ConversationPriority = 'low' | 'medium' | 'high' | 'urgent';
