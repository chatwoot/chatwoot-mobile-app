export type Theme = 'system' | 'light' | 'dark';
