export type UserRole = 'administrator' | 'agent';
